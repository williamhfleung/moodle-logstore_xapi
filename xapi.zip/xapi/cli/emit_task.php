<?php
define('CLI_SCRIPT', true);

#use tool_log\log\manager;
#use logstore_xapi\log\store;

require(__DIR__.'/../../../../../../config.php');
require_once("$CFG->libdir/datalib.php");
require(__DIR__.'/../classes/log/store.php');

//require('.. tool_log\log\manager');
//require('logstore_xapi\log\store');

global $DB;

$manager = get_log_manager();
$store = new store($manager);

$events = $DB->get_records('logstore_xapi_log');
//$store->process_events($events);

//$DB->delete_records_list('logstore_xapi_log', 'id', array_keys($events));

//mtrace("Sent learning records to LRS.");

echo var_export($manager, true);
echo var_export($store, true);
